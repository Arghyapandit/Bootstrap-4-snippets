# Change Log

<!-- All notable changes to the "bootstrap-v4 [year-2020]" extension will be documented in this file. -->

<!-- Check [Keep a Changelog](http://keepachangelog.com/) for recommendations on how to structure this file. -->

## [1.0.0]

- Initial release of Bootstrap 4 snippets extension
